### webpack4 
------
>webpack4 多入口，多页面项目构建案例。
本地访问 端口/index
本地访问 端口/login
文档参考：https://segmentfault.com/a/1190000014984842

#### npm install
```
npm install //或
cnpm install
```
### run
```
npm run dev //开发环境
npm run build //生产环境打包
```
文章介绍

### [点击前往](https://segmentfault.com/a/1190000014984842)