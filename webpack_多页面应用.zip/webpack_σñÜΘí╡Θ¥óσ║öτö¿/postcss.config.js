module.exports = {
	plugins: [
		require('autoprefixer')//自动添加css前缀
	]
};